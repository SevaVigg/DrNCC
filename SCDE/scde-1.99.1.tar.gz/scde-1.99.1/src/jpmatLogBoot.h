#ifndef _scde_JPMATLOGBOOT_H
#define _scde_JPMATLOGBOOT_H

#include <RcppArmadillo.h>

RcppExport SEXP jpmatLogBoot(SEXP Matl, SEXP Nboot, SEXP Seed) ;
RcppExport SEXP jpmatLogBatchBoot(SEXP Matll, SEXP Comp, SEXP Nboot, SEXP Seed) ;
RcppExport SEXP logBootPosterior(SEXP Models, SEXP Ucl, SEXP CountsI, SEXP Magnitudes, SEXP Nboot, SEXP Seed, SEXP ReturnIndividualPosteriors,SEXP LocalThetaFit, SEXP SquareLogitConc, SEXP EnsembleProbability) ;
RcppExport SEXP logBootBatchPosterior(SEXP Models, SEXP Ucl, SEXP CountsI, SEXP Magnitudes, SEXP BatchIL, SEXP Composition, SEXP Nboot, SEXP Seed, SEXP ReturnIndividualPosteriors, SEXP LocalThetaFit, SEXP SquareLogitConc);
#endif
