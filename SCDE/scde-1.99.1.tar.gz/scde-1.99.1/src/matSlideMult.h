#ifndef _scde_MATSLIDEMULT_H
#define _scde_MATSLIDEMULT_H

#include <RcppArmadillo.h>

RcppExport SEXP matSlideMult(SEXP Mat1, SEXP Mat2) ;

#endif
